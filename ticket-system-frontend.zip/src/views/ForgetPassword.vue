<template>
    <div class="hero min-h-screen " style="background: none">
        <div class="hero-content flex-col lg:flex-row-reverse">

            <div class="card  flex-shrink-0 w-10/5 max-w-sm shadow-2xl bg-base-100">
                <div class="card-body ">
                    <div class="form-control">
                        <label class="label">
                            <span class="label-text">Email</span>
                        </label>
                        <input type="text" placeholder="email" class="input input-bordered" />
                    </div>



                
                    <div class="form-control mt-6">
                        <button class="btn btn-primary">Send link</button>



                    </div>


                </div>
            </div>
        </div>
    </div>

</template>
<script setup lang="ts">
</script>